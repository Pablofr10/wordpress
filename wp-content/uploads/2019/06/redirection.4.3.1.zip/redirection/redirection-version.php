<?php

define( 'REDIRECTION_VERSION', '4.3.1' );
define( 'REDIRECTION_BUILD', '76c2e333a0fb0e417d3c1937d0c4045c' );
define( 'REDIRECTION_MIN_WP', '4.6' );
